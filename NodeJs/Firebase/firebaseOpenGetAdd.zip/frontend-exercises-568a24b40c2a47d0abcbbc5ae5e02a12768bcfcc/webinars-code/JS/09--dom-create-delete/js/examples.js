// const userName = prompt("What is your name?");
// console.log(userName);

// const pageTitle = document.createElement("h2");
// pageTitle.textContent = `Hello ${userName}`;

// document.body.insertAdjacentElement("afterbegin", pageTitle);

// document.body.insertAdjacentHTML(
//   "afterbegin",
//   `<h2 class='user-name'>${userName}</h2>`
// );

// const pageContainer = document.querySelector(".container");

// // pageContainer.children[0].style.display = "none";
// // pageContainer.children[0].remove();
// pageContainer.removeChild(pageContainer.children[0]);
