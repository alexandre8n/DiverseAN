const responce1 = alert("Here is the alert");
const responce2 = confirm("Is there any confirmation?");
const responce3 = prompt("Ask me anything and I would ignore it!");

if (responce2 === true) {
  console.log("He-he-he!");
} else {
  console.log("that's too bad!");
}

// switch (responce3) {
//   case "123":
//     console.log("you entered 123");
//     break;
// }
