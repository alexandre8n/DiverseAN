// document.addEventListener("keydown", (event) => {
//   console.log(event);
// });

// document.addEventListener("keypress", (event) => {
//   console.log(event);
// });

// document.addEventListener("keyup", (event) => {
//   console.log(event);
// });

// let userValue = "";

// document.getElementById("userName").addEventListener("keypress", (event) => {
//   userValue += event.key;
//   console.log(userValue);
// });

// const allPasswordInputs = document.querySelectorAll("input[type='password']");

// allPasswordInputs.forEach((input) => {
//   input.addEventListener("keyup", (event) => {
//     console.log(event.target.value);
//   });
// });
