// const header = document.body.children[0].children[0];
// const someText = document.body.children[0].children[1];

// header.style.color = "red";
// header.textContent = "Gogi was here";

// console.dir(header);

// console.dir(someText.textContent);
// console.dir(someText.innerText);
// console.dir(someText.innerHTML);

// const container = document.querySelector(".container");
// const header = document.getElementById("title");
// // const links = document.getElementsByClassName(".page-link");
// const paragraphs = document.getElementsByTagName("p");
// const namedLinks = document.getElementsByName("namedLink");
// const link = document.querySelector(".container .page-text a"); //first that matches the selector
// const links = document.querySelectorAll(".container .page-text a"); //all that matches selector

// links.forEach((link) => {
//   link.textContent = "I AM LINK!!!";
// });

// console.log(header, paragraphs, namedLinks, link, links);

// container.querySelector;
