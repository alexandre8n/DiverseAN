let user = "AH";
// I removed unneeded comment... AN: not remove !!
// localStorage.setItem(mainKey+'.'+user+'.'+rec1.id,JSON.stringify(rec1))
// localStorage.setItem(mainKey+'.'+user+'.'+rec2.id,JSON.stringify(rec2))
// localStorage.setItem('aaa', "ccc")
let records = getUserRecs(user);
for (let x of records) {
  addRecord(x);
}

addNewProjectsInCmb();
const selectProjElement = document.getElementById("Project");
if (selectProjElement.selectedIndex == 0) selectProjElement.selectedIndex = -1;

let rec = {
  id: "abc",
  user: "AH",
  date: "2024-01-01",
  project: "PRO1",
  task: "task1",
  effort: 5,
  comment: "Cool",
};
//let a = getKeys();

function onSubmit() {
  rec.id = generateUUIDv4();
  let selectElem = document.getElementsByName("cmbProj")[0];
  rec.project = selectElem.options[selectElem.selectedIndex].text;
  rec.task = document.getElementById("task").value;
  rec.comment = document.getElementById("comment").value;
  rec.date = document.getElementById("dateInput").value;
  rec.effort = Number(document.getElementById("efforts").value);
  saveObj(rec);
  addRecord(rec);
}
function addNewProjectsInCmb() {
  let cmbProj = document.getElementById("Project");
  let arrProj = getProjectsNames();
  let i = 1;
  for (let x of arrProj) {
    let opt = document.createElement("option");
    opt.value = ++i;
    opt.innerHTML = x;
    cmbProj.appendChild(opt);
  }
}
function addRecord(rec) {
  let tb = document.getElementById("tblBodyId");
  //let newrow= document.createElement('tr')створює елемент tr й присваює в змінну
  let newrow = tb.insertRow(0);
  const cols = ["date", "project", "task", "effort"];
  for (let fld of cols) {
    let td = document.createElement("td");
    td.textContent = rec[fld];
    newrow.appendChild(td);
  }
  newrow.id = rec.id;
  let tdButton = createTdWithButton("Edit", editclick);
  let tdButton1 = createTdWithButton("Delete", deleteclick);
  newrow.appendChild(tdButton);
  newrow.appendChild(tdButton1);
  //tb.appendChild(newrow)добавляє в кінець таблиців tbody
  return;
}
function createTdWithButton(btnTxt, btnOnclick) {
  let td = document.createElement("td");
  let tbtn = document.createElement("button");
  tbtn.innerHTML = btnTxt;
  tbtn.onclick = btnOnclick;
  td.appendChild(tbtn);
  return td;
}
function editclick(btn) {
  let parent = btn.srcElement.parentElement.parentElement;
  let id = parent.id;
  let dlg = document.getElementById("EditDlg");
  dlg.recRow = parent;
  dlg.showModal();
  initDlgData(dlg);
}
function deleteclick(btn) {
  let parent = btn.srcElement.parentElement.parentElement;
  let id = parent.id;
  deleteRecFromDB(id);
  removeTableRow(parent);

  console.log("delete click");
}
function generateUUIDv4() {
  //функція генератор уникальних id
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function (c) {
    let r = (Math.random() * 16) | 0;
    let v = c === "x" ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}
function removeTableRow(row) {
  // row.parentNode.removeChild(row);
  row.remove();
}
function onSubmitEdit(obj) {
  let dlg = document.getElementById("EditDlg");
  rec.id = dlg.recRow.id;
  let selectElem = document.getElementById("editPrjSelect");
  rec.project = selectElem.options[selectElem.selectedIndex].text;
  rec.task = document.getElementById("editTask").value;
  rec.comment = document.getElementById("editComment").value;
  rec.date = document.getElementById("editDateInput").value;
  rec.effort = Number(document.getElementById("editEfforts").value);
  saveObj(rec);
  updateTr(dlg.recRow, rec);
  dlg.close();
}
function clouseEdit() {
  let dlg = document.getElementById("EditDlg");
  dlg.close();
}
function closeProject() {
  let prj = document.getElementById("newProjectDlg");
  prj.close();
  const selectElement = document.getElementById("Project");
  if (selectElement.selectedIndex == 0) selectElement.selectedIndex = -1;
}
function updateTr(recRow, rec) {
  let tds = recRow.childNodes;
  let td0 = tds[0]; // дата
  let td1 = tds[1]; // проект
  let td2 = tds[2]; // задача
  let td3 = tds[3]; // потрачений час
  td0.innerHTML = rec.date;
  td1.innerHTML = rec.project;
  td2.innerHTML = rec.task;
  td3.innerHTML = String(rec.effort);
}
function initDlgData(editDlg) {
  let rec = getRecById(editDlg.recRow.id);
  let comment = document.getElementById("editComment");

  let projectCmb = document.getElementById("editPrjSelect");
  removeOptions(projectCmb);
  comment.value = rec.comment;
  let task = document.getElementById("editTask");
  task.value = rec.task;
  let effort = document.getElementById("editEfforts");
  effort.value = rec.effort;
  let date = document.getElementById("editDateInput");
  date.value = rec.date;
  let projects = getProjectsNames();
  let projectIsFound = false;
  projects.forEach((prjName) => {
    const opt = document.createElement("option");
    opt.innerHTML = prjName;
    opt.value = prjName;
    opt.selected = prjName == rec.project;
    if (opt.selected) {
      projectIsFound = true;
    }
    projectCmb.appendChild(opt);
  });
  if (!projectIsFound) {
    projectCmb.selectedIndex = -1;
  }
  // for (let x of projectCmb.options) {
  //   if (x.innerHTML == rec.project) x.selected = true;
  // }
}
function removeOptions(selectElement) {
  var i,
    L = selectElement.options.length - 1;
  for (i = L; i >= 0; i--) {
    selectElement.remove(i);
  }
}
function onAddNew(evt) {
  if (evt.target.value == "AddNew") {
    let newPrjDlg = document.getElementById("newProjectDlg");
    newPrjDlg.showModal();
  }
}
function onCancelNewProj() {
  let newPrjDlg = document.getElementById("newProjectDlg");
  let textareaEditProj = document.getElementById("editProject");
  textareaEditProj.value = "";
  newPrjDlg.close();
  const selectElement = document.getElementById("Project");
  if (selectElement.selectedIndex == 0) selectElement.selectedIndex = -1;
}
function saveNewProject() {
  let projName = editProject.value;
  let id = generateUUIDv4();
  const proj = { name: projName, id: id };
  if (!addProj(proj)) {
    document.getElementById("prgNmId").innerHTML = projName;
    document.getElementById("newProjErr").style.visibility = "visible";
    return;
  }
  updateProj(proj);
  onCancelNewProj();
}
function updateProj(proj) {
  let selectElement = document.getElementById("Project");
  //let dlg = dlgProj[0]; // Error
  //dlg.innerHTML=proj.name; // Error
  // you should create element option
  // set to it the text of proj (from variable proj)
  // set to it property "selected" = true;
  // add this element to the combobox
  let opt = document.createElement("option");
  opt.value = selectElement.options.count + 1; // some uniq value
  opt.innerHTML = proj.name; // name of the project
  opt.selected = true; // option should be selected = shown in combobox as active
  selectElement.appendChild(opt); // add option to combobox
}

function onNewProjClick(event) {
  let newPrjDlg = document.getElementById("newProjectDlg");
  newPrjDlg.showModal();
}
function onSelectClick(event) {
  // const target = event.target;
  // const targetTagName = target.tagName;
  // return;
  // let idx = event.currentTarget.selectedIndex;
  // if (idx != 0) return
  // let newPrjDlg = document.getElementById("newProjectDlg");
  // newPrjDlg.showModal();
  // return;
  // const target = event.target; AH one comment
  //  let selOpts = event.currentTarget.options;
  //  if (selOpts.length > 1) return;
  // if (event.target.value == "AddNew") {
  // }
}
