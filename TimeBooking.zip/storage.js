let mainKey = 'TimeBooking';
let mainProjKey = 'TimeBookingProj';
function saveObj(obj){
    const strJson = JSON.stringify(obj);
    localStorage.setItem(mainKey+'.'+user+'.'+obj.id,strJson);
    };
    function getKeys(){
        let keyArray = [];
        for(let i=0; i<localStorage.length; i++) {
            let key = localStorage.key(i);
            keyArray.push(key);
     } 
     return keyArray;
    }
function getRecById(id){
  let idRec =  mainKey+'.'+user+'.'+id
  let string = localStorage.getItem(idRec);
  let obj = JSON.parse(string);
  return obj;

}
function addProj(proj){
   let proestNames = getProjectsNames();
   if(proestNames.indexOf(proj.name) >=0 ) 
      return false;
      
   const strJson = JSON.stringify(proj);
    localStorage.setItem(mainProjKey+'.'+proj.id,strJson);
    return true;
};
   
function getProjectsNames(){
   let keys= getKeys()
   let goodKeys = keys.filter(key => key.startsWith(mainProjKey+'.'));
  let projNames = goodKeys.map(el=>JSON.parse(localStorage.getItem(el)).name );
  return projNames;
}

 function getUserRecs(user) {
    let keys =getKeys();
    let goodKeys = keys.filter(key => key.startsWith(mainKey+'.'+user+'.'));//startsWith стандартна функція
 let objs=[]
 for( let x of goodKeys){
    let string = localStorage.getItem(x);
    let obj = JSON.parse(string);
    objs.push(obj);
 }
 return objs;
 }   
 function clearAll(){
   localStorage.clear()
 }
 function deleteRecFromDB(recId){
   let key = mainKey+'.'+user+'.'+recId
   localStorage.removeItem(key);
 }