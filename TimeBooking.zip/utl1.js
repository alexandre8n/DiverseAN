function getRandomNumber(size) {
  return Math.floor(Math.random() * size);
}

// this function returns the number from "from" to "to";
function getRandomIntFromTo(from, to) {
  var size = to - from + 1;
  return from + getRandomNumber(size);
}

function getRandomDate(dateBase, intFromToday1, intFromToday2) {
  let dateobj = new Date();
  let dateOffset = getRandomIntFromTo(intFromToday1, intFromToday2);
  dateobj.setDate(dateBase.getDate() + dateOffset);
  var month = (dateobj.getMonth() + 1).toString().padStart(2, "0");
  var day = dateobj.getDate().toString().padStart(2, "0");
  var year = dateobj.getFullYear();
  let str = `${year}-${month}-${day}`;
  return str;
}

//let d2 = getRandomDate(new Date(), -100, +1);
