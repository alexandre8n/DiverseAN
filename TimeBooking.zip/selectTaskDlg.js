const task1Template = { taskName: "Task1", effort: 0, date: "2020-01-01" };
const myModal = document.getElementById("TaskSelectDlg");

function loadMyTasks() {
  let tasks = testGenTasks(15);
  return tasks;
}

function showTasksInGrid(tasks) {
  tasks.forEach((tsk) => {
    addTaskRec(tsk);
  });
}
function onSelTask(evnt) {
  hRef = evnt.currentTarget;
  const row1 = hRef.parentElement.parentElement;
  const selectedTaskName = row1.cells[0].innerText;
  closeTaskSelect(selectedTaskName);
}

function addTaskRec(rec) {
  let tb = document.getElementById("taskTblBodyId");
  //let newrow= document.createElement('tr')створює елемент tr й присваює в змінну
  let newrow = document.createElement("tr"); //tb.appendRow();
  const taskCols = Object.keys(task1Template);
  for (let fld of taskCols) {
    let td = document.createElement("td");
    td.textContent = rec[fld];
    newrow.appendChild(td);
  }
  var aElm = document.createElement("a");
  var createAText = document.createTextNode("Select and Exit");
  aElm.setAttribute("href", "#");
  aElm.appendChild(createAText);
  aElm.onclick = onSelTask;
  let tdLink = document.createElement("td");
  tdLink.appendChild(aElm);
  newrow.appendChild(tdLink);

  // newrow.id = rec.id;
  // let tdButton = createTdWithButton("Edit", editclick);
  // let tdButton1 = createTdWithButton("Delete", deleteclick);
  // newrow.appendChild(tdButton);
  // newrow.appendChild(tdButton1);
  tb.appendChild(newrow); //добавляє в кінець таблиців tbody
  return;
}
function onSelectTask() {
  document.body.style.filter = "brightness(0.8)"; // Dim the main screen
  const dlg = document.getElementById("TaskSelectDlg");
  const closeModalBtn = document.getElementById("closeModalBtn");
  dlg.style.display = "block";

  // Close the modal when the close button (X) is clicked
  closeModalBtn.addEventListener("click", function () {
    closeTaskSelect();
  });
  // close by clicking outside dialog
  myModal.addEventListener("click", function (event) {
    if (event.target === myModal) {
      closeTaskSelect();
    }
  });

  let tasks = loadMyTasks();
  showTasksInGrid(tasks);
  dlg.showModal();
}
function closeTaskSelect(selectedTaskName) {
  const dlg = document.getElementById("TaskSelectDlg");
  dlg.close();
  document.body.style.filter = ""; // Restore the brightness of the main screen
  dlg.style.display = "none"; // Hide the modal
  if (!selectedTaskName) return;
  selectedTaskName = selectedTaskName.trim();
  if (selectedTaskName && selectedTaskName.length > 0) {
    const inputSelectedTask = document.getElementById("task");
    inputSelectedTask.value = selectedTaskName;
  }
}

function onKeyUpTaskFilter() {
  const input = document.getElementById("FilterTasks").value.toUpperCase();
  const table = document.getElementById("TaskTableId");
  const tr = table.getElementsByTagName("tr");

  for (let i = 1; i < tr.length; i++) {
    const td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      const txtValue = td.textContent || td.innerText;
      tr[i].style.display =
        txtValue.toUpperCase().indexOf(input) > -1 ? "" : "none";
    }
  }
}

function testGenTasks(taskCount) {
  let tasks = [];
  const taskNames = [
    "Learn Js",
    "Learn Html",
    "Learn Css",
    "Gui design",
    "Coding tasks",
    "Communication",
  ];
  const effortRanges = { from: 1, to: 100 };
  let dateRange = 100; // range from today [today-100, today+0]
  let today = new Date();
  for (let i = 0; i < taskCount; i++) {
    const idxOfTask = getRandomIntFromTo(0, taskNames.length - 1);
    let effort = getRandomIntFromTo(effortRanges.from, effortRanges.to);
    let dat1 = getRandomDate(today, -dateRange, 0);
    tasks.push({ taskName: taskNames[idxOfTask], effort: effort, date: dat1 });
  }
  return tasks;
}

//let tsks1 = testGenTasks(20);
//+ button to close. Styles, closeTaskSelect
//+ search line: #FilterTasks
//+ styles of task-tables .TblInDlg
//+ generate random tasks for grid
//+ show tasks in grid
//+ close by clicking outside dialog
//+ scroll for the table body
//+ select task and show in task control
//+ filter tasks by name input
// todo: groupping tasks by name,sum(effort), max(date),
//       sort by last modify desc
// todo: loading tasks from storage
// todo: filter tasks by date range
//        all, from..to, week (this, prev, before prev), month(...), quarter (...)
//        could be in header from - to [...] week,month,year
//        2024-10-01 - 2024-12-10 [...]
